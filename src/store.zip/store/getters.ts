const getters = {
  token: (state:any) => state.user.token,
  name: (state:any) => state.user.name
}
export default getters