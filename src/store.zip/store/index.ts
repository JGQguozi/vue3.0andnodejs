// import { createStore, createLogger } from 'vuex'
// const debug = process.env.NODE_ENV !== 'production'
// const ms = require.context('./modules', true, /\.ts$/)
// const modules:any = {}
// ms.keys().forEach(k=>{
//   const n = k.substring(2,k.length - 3)
//   modules[n] = ms(k).default
  
// })
// console.log('modules===>',modules)
// // const store = createStore({
// //   modules: modules,
// //   strict: debug,
// //   plugins: debug ? [createLogger()] : []
// // })
// const store = createStore(modules)
// console.log('store===>',store)
// export default store

// import { createStore } from 'vuex'
// import getters from './modules2/getters'
// import actions from './modules2/actions'
// import mutations from './modules2/mutations'
// import state from './modules2/state'

// export default createStore({
//   getters,
//   actions,
//   mutations,
//   state
// })


import { createStore } from 'vuex'
import getters from './getters'
// 引入模块
const ms = require.context('./modules', true, /\.ts$/)
const modules:any = {}
ms.keys().forEach(k=>{
  const n = k.substring(2,k.length - 3)
  modules[n] = ms(k).default
  
})
console.log('modules===>',modules)
export default createStore({
  // getters,
  modules: modules
})


