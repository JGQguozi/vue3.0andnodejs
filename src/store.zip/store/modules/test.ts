export default ({
  namespaced: true,
  state: {
    count: 9999,
    foo: 'bar'
  },
  getter: {
    count: (state:any) => state.count,
    twoBars:(state:any) => state.foo.repeat(2)
    
  },
  mutations: {
    addCount(state:any,val:any){
      state.count ++
    }
  },
  actions: {
    // setAsyncName({commit:any},newName:String){
    //   commit('setName', newName:String)
    // }
  },
  modules: {
  }
})
