// initial state
// import { createStore } from "vuex";
// const state = () => ({
//   name: 'lisi',
//   id: 0,
//   token: '9995555555555'
// })
// // getters
// const getters = {}
// // actions
// const actions = {
//   // async getAllProducts ({ commit }) {
//   //   const products = await shop.getProducts()
//   //   commit('setProducts', products)
//   // }
// }
// // mutations
// const mutations = {
//   SET_NAME: (state:any,val:string)=>{
//     state.name = val
//   },
//   SET_TOKEN: (state:any,val:string)=>{
//     state.token = val
//   }
// }

// export default createStore({
//   state: state,
//   getters: getters,
//   actions: actions,
//   mutations: mutations
// })

export default ({
  namespaced: true,
  state: {
    name: '--',
    id: 0,
    token: ''
  },
  getter: {
    getName: (state:any) => state.name,
    getToken:(state:any) => state.getToken
    
  },
  mutations: {
    SET_NAME: (state:any,val:string)=>{
      state.name = val
    },
    SET_TOKEN: (state:any,val:string)=>{
      state.token = val
    },
  },
  actions: {
    // setAsyncName({commit:any},newName:String){
    //  commit('SET_NAME', newName)
    // }
  },
  modules: {
  }
})
