const mutations = {
  setName: (state:any,val:string)=>{
    state.name = val
  }
}
export default mutations