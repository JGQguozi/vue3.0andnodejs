const state = {
  name: '校长',
  age: 55
}
export default state